#                     PokemonJava
Bienvenidos a este proyecto:

- Mirar Trello el tablón para organizar tareas.

- Si todavia no formas parte de este proyecto pero quieres participar, escribidme a mi correo:

ish.professional@gmail.com

- Antes de la integración hay que tener el codigo documentado y testado.

Dicho esto a disfrutar!!!:+1:^^

PARTICIPANTES:

 - https://github.com/ishmilan

 - https://github.com/yatastinson